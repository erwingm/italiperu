<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contac extends Model
{
    //
    // public function program(){
        
    //     return $this->belongsTo(Program::class);
    // }
    // public function sede(){

    //     return $this->belongsTo(Sede::class);
    // }
}
